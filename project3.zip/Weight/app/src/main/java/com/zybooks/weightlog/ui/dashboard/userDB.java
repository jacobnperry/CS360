package com.zybooks.weightlog.ui.dashboard;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;

public class userDB extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight.db";
    private static final int VERSION = 1;
    private static final String COL_ID = "ID";
    private static final String COL_DATE = "DATE";
    private static final String COL_WEIGHT = "WEIGHT";
    private static final String TABLE = "WEIGHT_LOG";
    private static final String TAG = null;





    public userDB(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    public boolean  addWeightToDB(String date, String todaysWeight) {
        date = "today";
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(userDB.COL_DATE, date);
        values.put(userDB.COL_WEIGHT, todaysWeight);
        long id = db.insert(userDB.TABLE, null, values);
        return id != -1;
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + userDB.TABLE + " (" +
                userDB.COL_ID + " integer primary key autoincrement, " +
                userDB.COL_DATE + " text, " +
                userDB.COL_WEIGHT + " text, ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + userDB.TABLE);
        onCreate(db);
    }


}


