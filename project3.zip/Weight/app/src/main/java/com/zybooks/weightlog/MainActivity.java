package com.zybooks.weightlog;

import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;


import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.zybooks.weightlog.databinding.ActivityMainBinding;

import org.w3c.dom.Text;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = null;
    private ActivityMainBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {





        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.navView, navController);


        WeightDatabase[] weightArray;
        weightArray = new WeightDatabase[3];
        weightArray[0] = new WeightDatabase("1/2/21", 175);
        weightArray[1] = new WeightDatabase("1/3/21", 177);
        weightArray[2] = new WeightDatabase("1/4/21", 180);





    }

    public void onButtonShowPopupWindowClick(View view) {

        // inflate the layout of the popup window
        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.popup_window, null);

        // create the popup window
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);

        // show the popup window
        // which view you pass in doesn't matter, it is only used for the window tolken
        popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);

        // dismiss the popup window when touched

    }




    public void sayHello(View view){
        TextView dialogMessage = (TextView) findViewById(R.id.textView2);
        EditText username = (EditText) findViewById(R.id.usernameInput);
        String sUsername = username.getText().toString();
        if (sUsername.length() == 0){
            dialogMessage.setVisibility(View.VISIBLE);
            username.setError("");
        }else {
            TextView greetText = (TextView) findViewById(R.id.textGreeting);
            String stringGreet = greetText.getText().toString();
            greetText.setVisibility(View.VISIBLE);
            greetText.setText("Hello " + sUsername);
        }
        Log.d("TAG", "This is working");
    }

    public void onNavClick(View view){new PopupWindow();}




    public void hasPermissions(View view) {
            new PopupWindow();
        }


    public void getActivity(){

    }

    /*public boolean addWeightToDB(View view,Context context,String date, int weight) {
        userDB db = new userDB(context, date, null, weight);
        userDB.addWeightToDB();
        long id = 1;
        return id != -1;
    }*/
    
    public void addWeightToDB(View view){
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yy");
        LocalDateTime now = LocalDateTime.now();
        System.out.println(dtf.format(now));
        LocalDateTime date = now;
        TextView firstDate = (TextView) findViewById(R.id.firstDate);
        TextView firstWeight = (TextView) findViewById(R.id.firstWeight);
        EditText weight = (EditText) findViewById(R.id.todaysWeight);
        String todaysWeight = weight.getText().toString();
        firstDate.setText(dtf.format(date));
        firstWeight.setText(todaysWeight);
        Log.d(TAG, todaysWeight);

    }
}