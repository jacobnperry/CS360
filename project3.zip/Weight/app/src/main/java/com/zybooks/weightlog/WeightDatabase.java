package com.zybooks.weightlog;

import android.content.Context;
import android.content.res.Resources;
import java.util.ArrayList;
import java.util.List;


public class WeightDatabase {
    String date;
    int currentWeight;

    public WeightDatabase(String date, int weight) {
        // This constructor has one parameter, name.
        this.date = date;
        this.currentWeight = weight;
        System.out.println("Name chosen is :" + weight );
    }
}


